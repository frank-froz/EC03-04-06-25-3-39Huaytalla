const items = [
  {
    id: 1,
    name: "Presentación Proyecto Creativo",
    image: "/public/dis1.png",
    cta: "logos",
  },
    
  {
    id: 2,
    name: "Presentación Diseño Gráfico",
    image: "/public/dis2.png",
    cta: "flyers",
  },
  {
    id: 3,
    name: "Presentación Diseño Gráfico",
    image: "/public/dis3.png",
    cta: "banner",
  },
  {
    id: 4,
    name: "Presentación Diseño Gráfico",
    image: "/public/dis4.png",
    cta: "currículums",
  },
  {
    id: 5,
    name: "Presentación Diseño Gráfico",
    image: "/public/dis5.png",
    cta: "collage",
  },
  {
    id: 6,
    name: "Presentación Diseño Gráfico",
    image: "/public/dis6.png",
    cta: "pósters",
  },

];


export default items;
