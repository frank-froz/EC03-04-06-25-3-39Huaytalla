import { useEffect, useState } from 'react';
import data from '../data/items';
import ItemCard from '../components/ItemCard';
import SearchBar from '../components/SearchBar';
import LoadingSkeleton from '../components/LoadingSkeleton';

export default function Items() {
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState([]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setItems(data);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const filtered = items.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="product-search-container">
        <SearchBar setSearch={setSearch} />
      </div>
      <div className="items-page">

        <div className="grid">
          {loading
            ? <LoadingSkeleton />
            : filtered.map(item => <ItemCard key={item.id} item={item} />)}
        </div>
      </div>
    </div>
  );
}
