import { useState } from 'react';
import { toast } from 'react-toastify';

export default function ContactForm() {
  const [form, setForm] = useState({ nombre: '', correo: '', mensaje: '' });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();
    if (!form.nombre || !form.correo || !form.mensaje) return toast('Completa todos los campos');
    toast('Gracias por contactarnos');
    setForm({ nombre: '', correo: '', mensaje: '' });
  };

  return (
    <form className="contact-form" onSubmit={handleSubmit}>
      <input name="nombre" value={form.nombre} onChange={handleChange} placeholder="Nombre" />
      <input name="correo" value={form.correo} onChange={handleChange} placeholder="Correo" />
      <textarea name="mensaje" value={form.mensaje} onChange={handleChange} placeholder="Mensaje"></textarea>
      <button type="submit">Enviar</button>
    </form>

  );
}
