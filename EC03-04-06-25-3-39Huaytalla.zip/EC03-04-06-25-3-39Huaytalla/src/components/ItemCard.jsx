import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';

export default function ItemCard({ item }) {
  const [fav, setFav] = useState(false);

  useEffect(() => {
    const favs = JSON.parse(localStorage.getItem('favorites')) || [];
    setFav(favs.includes(item.id));
  }, [item.id]);

  const toggleFav = () => {
    const favs = JSON.parse(localStorage.getItem('favorites')) || [];
    let updated;
    if (favs.includes(item.id)) {
      updated = favs.filter(id => id !== item.id);
      toast('Removido de favoritos');
    } else {
      updated = [...favs, item.id];
      toast('Agregado a favoritos');
    }
    localStorage.setItem('favorites', JSON.stringify(updated));
    setFav(!fav);
  };

  return (
    <div className="item-card">
      <img src={item.image} alt={item.name} />
      <h3>{item.name}</h3>
      <p>{item.cta}</p>
      <button onClick={toggleFav}>
        {fav ? '💙 Quitar' : '🤍 Favorito'}
      </button>
    </div>
  );
}
