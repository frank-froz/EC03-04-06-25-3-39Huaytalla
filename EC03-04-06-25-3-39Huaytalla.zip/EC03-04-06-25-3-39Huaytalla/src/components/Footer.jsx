export default function Footer() {
  return (
    <footer className="footer">
      <p>&copy; © 2025 Todos los derechos reservados, Canva®</p>
      <p>Política de privacidad | Condiciones</p>
    </footer>
  );
}
