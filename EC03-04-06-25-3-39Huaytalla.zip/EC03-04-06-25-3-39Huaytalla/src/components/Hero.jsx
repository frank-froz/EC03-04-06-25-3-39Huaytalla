import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import 'swiper/css';
import 'swiper/css/pagination';

import img1 from '../../public/img1.png'
import img2 from '../../public/img2.png'
import img3 from '../../public/img3.png'
import img4 from '../../public/img4.png'

export default function Hero() {

    const images = [img1, img2, img3, img4];
    
    return(
      <section>
        <Swiper 
            modules={[Autoplay, Pagination]}
            autoplay={{delay: 4000}}
            loopd
            pagination={{ clickable: true }}
            className="hero-swiper"
        >
            {images.map((img, index) => (
                <SwiperSlide key={index}>
                    <img
                        src={img}
                        alt={`Slide ${index + 1}`}
                        className="hero-image"
                        style={{ width: '100%', height: 'auto' }}
                        
                    />
                </SwiperSlide>
            ))}
        </Swiper>
        </section>
    );
}



