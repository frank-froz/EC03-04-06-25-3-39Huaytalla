import { useState, useEffect } from 'react';
import useDebounce from '../hooks/useDebounce';

export default function SearchBar({ setSearch }) {
  const [value, setValue] = useState('');
  const debounced = useDebounce(value, 400);

  useEffect(() => {
    setSearch(debounced);
  }, [debounced]);

  return (
    <input
      className='search-input'
      type="text"
      placeholder="Buscar diseño..."
      value={value}
      onChange={e => setValue(e.target.value)}
    />
  );
}
