import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';

export default function LoadingSkeleton() {
  return (
    <div className="loading">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i}>
          <Skeleton height={128} />
          <Skeleton count={2} />
        </div>
      ))}
    </div>
  );
}