import { Link } from 'react-router-dom';

export default function Header() {
  return (
    <header className="header">
      <div>
        <a href="/">
        <span>
          <img src="https://static.canva.com/web/images/8439b51bb7a19f6e65ce1064bc37c197.svg" alt="" role="presentation"/>
        </span>
        </a>
      </div>
      <nav>
        <Link to="/">Inicio</Link>
        <Link to="/items">Catálogo</Link>
        <Link to="/contact">Contacto</Link>
      </nav>
    </header>
  );
}
